window.onload = function() {
let canvas = document.getElementById('myCanvas');
let context = canvas.getContext('2d');


	context.shadowOffsetX = 5; // Тень
	context.shadowOffsetY = 5; // Тень
	context.shadowColor = "#bbbbbb"; // Цвет тени
	context.shadowBlur = 6; // Степень размытия тени
	
	context.beginPath();
	context.fillStyle = "#dffafb";
	context.strokeStyle = '#94dfec';
    context.arc(180,150,20,0,Math.PI*2,true); // Внешняя окружность (левая рука)
	context.moveTo(208,370);
	context.arc(180,370,28,0,Math.PI*2,true); // Внешняя окружность (левая нога)
	context.moveTo(340,150);
	context.arc(320,150,20,0,Math.PI*2,true); // Внешняя окружность (правая рука)
	context.moveTo(348,370);
	context.arc(320,370,28,0,Math.PI*2,true); // Внешняя окржность (правая нога)
	context.stroke();
	context.fill();
	
	context.beginPath();
	context.fillStyle = "#dffafb";
	context.strokeStyle = '#94dfec';
    context.arc(250,300,85,0,Math.PI*2,true); // Внешняя окружность (туловище, нижняя часть)
	context.moveTo(253,185);
	context.stroke();
	context.fill();
	

	
	
	
	context.beginPath();
	context.fillStyle = "#dffafb";
	context.strokeStyle = '#94dfec';
    context.arc(250,180,65,0,Math.PI*2,true); // Внешняя окружность (туловище, средняя часть)
	context.moveTo(253,185);
	context.stroke();
	context.fill();
	
	context.beginPath();
	context.fillStyle = "#f4f114";
	context.strokeStyle = '#9f7800';
	context.shadowOffsetX = 0; // Тень
	context.shadowOffsetY = 0; // Тень
	context.shadowBlur = 0; // Степень размытия тени
    context.arc(250,185,3,0,Math.PI*2,true); // Средняя пуговица
	context.moveTo(253,145);
    context.arc(250,145,3,0,Math.PI*2,true); // Верхняя пуговица
	context.moveTo(253,225);
    context.arc(250,225,3,0,Math.PI*2,true); // Нижняя пуговица
	context.stroke();
	context.fill();

	
	context.shadowOffsetX = 5; // Тень
	context.shadowOffsetY = 5; // Тень
	context.shadowColor = "#bbbbbb"; // Цвет тени
	context.shadowBlur = 6; // Степень размытия тени
	
	context.beginPath();
	context.fillStyle = "#dffafb";
	context.strokeStyle = '#94dfec';
	context.arc(250,75,50,0,Math.PI*2,true); // Внешняя окружность (голова)
	context.stroke();
	context.fill();
	
	context.beginPath();
	context.strokeStyle = "#e3992f";
	context.fillStyle = "#ffd200";
	context.arc(250,85,10,Math.PI*1.5,Math.PI*0.4,false); //основание морковки (против часовой стрелки)
	context.lineTo(180,85);
	context.lineTo(250,75);
    context.stroke();
	context.fill();
	
	
	context.beginPath(); // Речевая выноска
	context.strokeStyle = "#9900FF";
	context.fillStyle = "#FFCC99";
    context.moveTo(400,0);
	context.quadraticCurveTo(350,0,350,45);
    context.quadraticCurveTo(350,75,375,80);
	context.quadraticCurveTo(375,95,355,105);
	context.quadraticCurveTo(385,95,385,80);
	context.quadraticCurveTo(450,85,450,45);
	context.quadraticCurveTo(450,0,400,0);
    context.stroke();
	context.fill();
	
	
	
	context.beginPath();
	context.shadowOffsetX = 0; // Тень
	context.shadowOffsetY = 0; // Тень
	context.shadowBlur = 0; // Степень размытия тени
	context.moveTo(285,75);
	context.strokeStyle = '#f6245a';
    context.arc(250,75,35,0,Math.PI*0.5,false);  // рот (по часовой стрелке)
	context.stroke();
	
	
	context.beginPath();
	context.fillStyle = "black";
	context.font = "22px serif";
	context.fillText("Hello!", 370, 50);
    context.moveTo(240,65);
    context.arc(235,65,5,0,Math.PI*2,true);  // Левый глаз
    context.moveTo(270,65);
    context.arc(265,65,5,0,Math.PI*2,true);  // Правый глаз
	context.fill();
	
	
	
	
	
}